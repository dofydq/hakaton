import { useAuthStore } from '@/lib/store/auth-store'

const API_BASE = '/api'

interface ApiError {
  status: 'error'
  message: string
  details?: string[]
}

class ApiClient {
  private getHeaders(): HeadersInit {
    const token = useAuthStore.getState().token
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    }
    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }
    return headers
  }

  private async handleResponse<T>(response: Response): Promise<T> {
    if (response.status === 401) {
      useAuthStore.getState().logout()
      if (typeof window !== 'undefined') {
        window.location.href = '/login'
      }
      throw new Error('Unauthorized')
    }

    if (response.status === 403) {
      throw new Error('Access denied or subscription expired')
    }

    if (!response.ok) {
      const error: ApiError = await response.json().catch(() => ({
        status: 'error',
        message: 'An unexpected error occurred',
      }))
      throw new Error(error.message)
    }

    return response.json()
  }

  async get<T>(endpoint: string): Promise<T> {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      method: 'GET',
      headers: this.getHeaders(),
    })
    return this.handleResponse<T>(response)
  }

  async post<T>(endpoint: string, data?: unknown): Promise<T> {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: data ? JSON.stringify(data) : undefined,
    })
    return this.handleResponse<T>(response)
  }

  async patch<T>(endpoint: string, data?: unknown): Promise<T> {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: data ? JSON.stringify(data) : undefined,
    })
    return this.handleResponse<T>(response)
  }

  async delete<T>(endpoint: string): Promise<T> {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    })
    return this.handleResponse<T>(response)
  }
}

export const api = new ApiClient()

// Auth API
export const authApi = {
  register: (data: {
    email: string
    password: string
    name: string
    specialization?: string
    bio?: string
  }) => api.post('/auth/register', data),

  login: (data: { email: string; password: string }) =>
    api.post<{ access_token: string; token_type: string }>('/auth/login', data),

  me: () => api.get<{ user: import('@/lib/store/auth-store').User }>('/auth/me'),
}

// Tests API
export interface Test {
  id: string
  title: string
  description?: string
  questions: Question[]
  created_at: string
  updated_at: string
  session_count: number
}

export interface Question {
  id: string
  text: string
  type: 'single' | 'multiple'
  options: { id: string; text: string; value: number }[]
}

export const testsApi = {
  list: () => api.get<Test[]>('/tests'),
  get: (id: string) => api.get<Test>(`/tests/${id}`),
  create: (data: Partial<Test>) => api.post<Test>('/tests', data),
  update: (id: string, data: Partial<Test>) => api.patch<Test>(`/tests/${id}`, data),
  delete: (id: string) => api.delete(`/tests/${id}`),
}

// Links API
export interface TestLink {
  id: string
  test_id: string
  test_title: string
  label: string
  url: string
  created_at: string
  submission_count: number
}

export const linksApi = {
  list: () => api.get<TestLink[]>('/links'),
  create: (data: { test_id: string; label: string }) =>
    api.post<TestLink>('/links', data),
}

// Results API
export interface TestResult {
  id: string
  test_id: string
  test_title: string
  link_label: string
  client_name?: string
  client_email?: string
  completed_at: string
  scores: Record<string, number>
}

export const resultsApi = {
  list: (params?: { test_id?: string; label?: string }) => {
    const searchParams = new URLSearchParams()
    if (params?.test_id) searchParams.set('test_id', params.test_id)
    if (params?.label) searchParams.set('label', params.label)
    const query = searchParams.toString()
    return api.get<TestResult[]>(`/results${query ? `?${query}` : ''}`)
  },
  counts: () => api.get<{ total: number; by_test: Record<string, number> }>('/results/counts'),
  downloadReport: (id: string, type: 'client' | 'prof') =>
    `${API_BASE}/reports/download/${id}?type=${type}`,
}

// Admin API
export const adminApi = {
  users: () => api.get<import('@/lib/store/auth-store').User[]>('/admin/users'),
  updateUser: (id: string, data: Partial<import('@/lib/store/auth-store').User>) =>
    api.patch(`/admin/users/${id}`, data),
  stats: () =>
    api.get<{
      total_users: number
      active_users: number
      total_tests: number
      total_sessions: number
    }>('/admin/stats'),
}

// Public API
export const publicApi = {
  getLink: (linkId: string) =>
    api.get<{
      test_title: string
      test_description?: string
      questions: Question[]
    }>(`/public/links/${linkId}`),
  submit: (data: {
    link_id: string
    answers: Record<string, string | string[]>
    client_name?: string
    client_email?: string
  }) => api.post<{ message: string; result_id?: string }>('/public/submit', data),
}
