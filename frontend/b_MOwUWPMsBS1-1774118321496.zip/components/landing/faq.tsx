'use client'

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'

const faqs = [
  {
    question: 'What is ProfDNK?',
    answer:
      'ProfDNK is a professional CRM platform designed specifically for psychologists. It helps you create psychological assessments, manage client sessions, track progress, and generate detailed reports.',
  },
  {
    question: 'How does client testing work?',
    answer:
      'You can create custom tests with various question types (single choice, multiple choice). Generate unique links for each client or group, and they can complete the assessment anonymously. Results are automatically calculated and stored in your dashboard.',
  },
  {
    question: 'Is my client data secure?',
    answer:
      'Yes, security is our top priority. All data is encrypted at rest and in transit. We are GDPR compliant and follow best practices for handling sensitive psychological data.',
  },
  {
    question: 'Can I export reports?',
    answer:
      'Yes, Pro and Enterprise plans include the ability to export detailed reports in DOCX format. You can generate both client-facing summaries and detailed professional reports for your records.',
  },
  {
    question: 'What happens after my trial ends?',
    answer:
      'After your 14-day trial, you can choose to upgrade to a paid plan to continue using all features. Your data will be preserved, and you can pick up right where you left off.',
  },
  {
    question: 'Can I cancel my subscription anytime?',
    answer:
      'Yes, you can cancel your subscription at any time. Your access will continue until the end of your billing period, and you can export all your data before cancellation.',
  },
]

export function FAQ() {
  return (
    <section id="faq" className="py-24">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="font-outfit text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Frequently Asked Questions
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Everything you need to know about ProfDNK
          </p>
        </div>

        <Accordion type="single" collapsible className="mt-12">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger className="text-left text-foreground">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  )
}
