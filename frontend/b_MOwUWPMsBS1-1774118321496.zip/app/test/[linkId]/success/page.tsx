import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Brain, CheckCircle, Home } from 'lucide-react'

export default function TestSuccessPage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-primary/5 via-background to-accent/5">
      {/* Header */}
      <header className="border-b border-border/40 bg-background/80 backdrop-blur-lg">
        <div className="mx-auto flex h-14 max-w-3xl items-center justify-center px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Brain className="h-4 w-4" />
            </div>
            <span className="font-outfit font-semibold">ProfDNK</span>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="flex flex-1 items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-green-500/10">
              <CheckCircle className="h-10 w-10 text-green-500" />
            </div>
            <CardTitle className="font-outfit text-2xl">Test Completed!</CardTitle>
            <CardDescription className="text-base">
              Thank you for completing the assessment
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-muted-foreground">
              <p>
                Your responses have been submitted successfully. The psychologist 
                will review your answers and may follow up with you if needed.
              </p>
              <div className="rounded-lg bg-muted/50 p-4 text-sm">
                <p>
                  If you have any questions or concerns about this assessment, 
                  please contact the psychologist who sent you this test.
                </p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button asChild variant="outline">
              <Link href="/">
                <Home className="mr-2 h-4 w-4" />
                Return to Home
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40 bg-background/80 py-4 text-center text-sm text-muted-foreground">
        Powered by ProfDNK - Professional Psychology CRM
      </footer>
    </div>
  )
}
