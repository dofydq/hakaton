'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm, useFieldArray } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { FieldGroup, Field, FieldLabel } from '@/components/ui/field'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Spinner } from '@/components/ui/spinner'
import { Plus, Trash2, GripVertical, ArrowLeft, Save } from 'lucide-react'
import Link from 'next/link'
import { testsApi } from '@/lib/api/client'

const optionSchema = z.object({
  text: z.string().min(1, 'Option text is required'),
  value: z.number(),
})

const questionSchema = z.object({
  text: z.string().min(1, 'Question text is required'),
  type: z.enum(['single', 'multiple']),
  options: z.array(optionSchema).min(2, 'At least 2 options required'),
})

const testSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  questions: z.array(questionSchema).min(1, 'At least 1 question required'),
})

type TestForm = z.infer<typeof testSchema>

export default function NewTestPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  const {
    register,
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<TestForm>({
    resolver: zodResolver(testSchema),
    defaultValues: {
      title: '',
      description: '',
      questions: [
        {
          text: '',
          type: 'single',
          options: [
            { text: '', value: 0 },
            { text: '', value: 1 },
          ],
        },
      ],
    },
  })

  const { fields: questions, append: appendQuestion, remove: removeQuestion } = useFieldArray({
    control,
    name: 'questions',
  })

  const onSubmit = async (data: TestForm) => {
    setIsLoading(true)
    try {
      await testsApi.create(data)
      toast.success('Test created successfully!')
      router.push('/dashboard/tests')
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to create test')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard/tests">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back to tests</span>
          </Link>
        </Button>
        <div>
          <h1 className="font-outfit text-2xl font-bold text-foreground">Create New Test</h1>
          <p className="text-muted-foreground">Build a psychological assessment</p>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Basic Info */}
        <Card>
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
            <CardDescription>Set the title and description for your test</CardDescription>
          </CardHeader>
          <CardContent>
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="title">Test Title</FieldLabel>
                <Input
                  id="title"
                  placeholder="e.g., Anxiety Assessment Scale"
                  {...register('title')}
                />
                {errors.title && (
                  <p className="text-sm text-destructive">{errors.title.message}</p>
                )}
              </Field>
              <Field>
                <FieldLabel htmlFor="description">Description (Optional)</FieldLabel>
                <Textarea
                  id="description"
                  placeholder="Describe what this test measures..."
                  rows={3}
                  {...register('description')}
                />
              </Field>
            </FieldGroup>
          </CardContent>
        </Card>

        {/* Questions */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-outfit text-lg font-semibold text-foreground">Questions</h2>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() =>
                appendQuestion({
                  text: '',
                  type: 'single',
                  options: [
                    { text: '', value: 0 },
                    { text: '', value: 1 },
                  ],
                })
              }
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Question
            </Button>
          </div>

          {questions.map((question, qIndex) => (
            <QuestionCard
              key={question.id}
              index={qIndex}
              register={register}
              control={control}
              errors={errors}
              watch={watch}
              setValue={setValue}
              onRemove={() => removeQuestion(qIndex)}
              canRemove={questions.length > 1}
            />
          ))}

          {errors.questions?.root && (
            <p className="text-sm text-destructive">{errors.questions.root.message}</p>
          )}
        </div>

        {/* Submit */}
        <div className="flex justify-end gap-3">
          <Button type="button" variant="outline" asChild>
            <Link href="/dashboard/tests">Cancel</Link>
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? <Spinner className="mr-2" /> : <Save className="mr-2 h-4 w-4" />}
            Save Test
          </Button>
        </div>
      </form>
    </div>
  )
}

function QuestionCard({
  index,
  register,
  control,
  errors,
  watch,
  setValue,
  onRemove,
  canRemove,
}: {
  index: number
  register: any
  control: any
  errors: any
  watch: any
  setValue: any
  onRemove: () => void
  canRemove: boolean
}) {
  const { fields: options, append: appendOption, remove: removeOption } = useFieldArray({
    control,
    name: `questions.${index}.options`,
  })

  const questionType = watch(`questions.${index}.type`)

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-sm font-semibold text-primary">
            {index + 1}
          </div>
          <div>
            <CardTitle className="text-base">Question {index + 1}</CardTitle>
          </div>
        </div>
        {canRemove && (
          <Button type="button" variant="ghost" size="icon" onClick={onRemove}>
            <Trash2 className="h-4 w-4 text-muted-foreground" />
            <span className="sr-only">Remove question</span>
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        <FieldGroup>
          <Field>
            <FieldLabel>Question Text</FieldLabel>
            <Textarea
              placeholder="Enter your question..."
              rows={2}
              {...register(`questions.${index}.text`)}
            />
            {errors.questions?.[index]?.text && (
              <p className="text-sm text-destructive">
                {errors.questions[index].text.message}
              </p>
            )}
          </Field>

          <Field>
            <FieldLabel>Question Type</FieldLabel>
            <Select
              value={questionType}
              onValueChange={(value) => setValue(`questions.${index}.type`, value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="single">Single Choice</SelectItem>
                <SelectItem value="multiple">Multiple Choice</SelectItem>
              </SelectContent>
            </Select>
          </Field>
        </FieldGroup>

        {/* Options */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <FieldLabel>Options</FieldLabel>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => appendOption({ text: '', value: options.length })}
            >
              <Plus className="mr-1 h-3 w-3" />
              Add Option
            </Button>
          </div>

          {options.map((option, oIndex) => (
            <div key={option.id} className="flex items-center gap-2">
              <GripVertical className="h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={`Option ${oIndex + 1}`}
                className="flex-1"
                {...register(`questions.${index}.options.${oIndex}.text`)}
              />
              <Input
                type="number"
                placeholder="Value"
                className="w-20"
                {...register(`questions.${index}.options.${oIndex}.value`, {
                  valueAsNumber: true,
                })}
              />
              {options.length > 2 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeOption(oIndex)}
                >
                  <Trash2 className="h-4 w-4 text-muted-foreground" />
                </Button>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
